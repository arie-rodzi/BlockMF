// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract BlockMF {
    struct LoanRecord {
        string borrowerId;
        uint256 amount;
        uint256 eligibilityScore;
        uint256 trustScore;
        string status;
        uint256 timestamp;
    }

    LoanRecord[] public loans;

    event LoanRecorded(string borrowerId, uint256 amount, string status, uint256 timestamp);

    function recordLoan(
        string memory borrowerId,
        uint256 amount,
        uint256 eligibilityScore,
        uint256 trustScore,
        string memory status
    ) public {
        loans.push(LoanRecord(borrowerId, amount, eligibilityScore, trustScore, status, block.timestamp));
        emit LoanRecorded(borrowerId, amount, status, block.timestamp);
    }

    function getLoanCount() public view returns (uint256) {
        return loans.length;
    }
}
